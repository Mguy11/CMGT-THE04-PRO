class GameOverScreen {
    constructor() {

    }
    update() {

    }
}